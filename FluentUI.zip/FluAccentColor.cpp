#include "FluAccentColor.h"

FluAccentColor::FluAccentColor(QObject *parent) : QObject{parent} {
}
